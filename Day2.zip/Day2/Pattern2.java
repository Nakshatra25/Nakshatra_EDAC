package Day2; 

public class Pattern2{
public static void main(String args[]){
int i,j,k;
for( i=1; i<=9; i++)
{
   for( j=0; j<=9-i; j++)
   {
       System.out.print(" ");
}
for( k=1; k<=i; k++)
{
       System.out.print(k+" ");
}
System.out.print("\n");
        }
    }
}