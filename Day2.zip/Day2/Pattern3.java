package Day2; 
public class Pattern3 
{
     public static void main(String[] args)
    {
        int sp=20;
        int i,j,k;
        for(i=1;i<10;i++)
        {
            for(k=1;k<=sp;k++)
            {
                System.out.print(" ");
            }
            sp--;
            for(j=1;j<=i;j++)
            {
                System.out.print("* ");
            }
           System.out.println();
        }
    }
}



    
   