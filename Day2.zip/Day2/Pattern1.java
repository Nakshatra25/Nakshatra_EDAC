package Day2;

class Pattern1
{
    public static void main(String[] args)
    {
        int sp=20;
        int i,j,k;
        for(i=1;i<9;i++)
        {
            for(k=1;k<=sp;k++)
            {
                System.out.print(" ");
            }
            sp--;
            for(j=1;j<=i;j++)
            {
                System.out.print(i+" ");
            }
           System.out.println();
        }
    }
}