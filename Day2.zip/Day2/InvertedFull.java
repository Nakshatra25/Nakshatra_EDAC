package Day2;

import java.util.*;
public class InvertedFull
{
	public static void main(String args[])
	{
		for(int i=1 ; i<=6 ; i++)
		{
			for(int j=1 ; j<=i ; j++)
			{
			System.out.print("  ");
			}
		
			for(int m=6 ; m>=i ; m--)
			{	
				System.out.print("*");
				m--;
				System.out.print("   ");
			}
			for(int k=6 ; k>i ; k--)
			{
				System.out.print("*");
				k--;
				System.out.print("   ");
			}
			System.out.println();
		}
	}
}