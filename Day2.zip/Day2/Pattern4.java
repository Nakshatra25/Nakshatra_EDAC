package Day2;
import java.util.Scanner;
class Pattern4
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int row =  input.nextInt();
        int spacen = row;
        
        for(int i=1; i<=row; i++)
        {
           int c=1;
           for(int j=1;j<=spacen; j++)
           {
              System.out.print(" "); 
           }
            spacen--;
            for(int k=1;k<=i ; k++)
            {
               System.out.print(c);
               c++;
            }
              c= c-2;
              
              for(int l=2; l<=i; l++)
              {
                  System.out.print(c);
                  c--;
              }
              
              c=1;
              System.out.println();
        }
}
}