package CoreJava;
import java.util.*;
public class Ques5
{


 public static void main(String[] args) {
     for(int i=0; i<args.length; i++)
     {
         System.out.println(args[i]);
     }
 }
}
