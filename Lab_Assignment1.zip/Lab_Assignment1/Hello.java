package CoreJava;
import java.util.*;  
        
class  Hello
{
   public static void main(String args[])
   {
       Scanner sc = new Scanner(System.in);
       String s = sc.next();
       System.out.println(s);
        System.out.println("Hello World");
       
   }
}